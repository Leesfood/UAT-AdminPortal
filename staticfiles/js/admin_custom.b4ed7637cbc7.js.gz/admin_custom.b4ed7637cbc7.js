// Example: Add a custom alert when the admin page loads
document.addEventListener("DOMContentLoaded", function() {
    alert("Welcome to the custom HRM Admin Dashboard!");
});
